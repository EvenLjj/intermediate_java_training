import java.awt.Color;
import java.awt.Graphics;

public abstract class Polygon extends Shape
{

    public Polygon(Color color, boolean filled)
    {
      //TODO Complete implementation
    }

    @Override
    public void draw(Graphics g)
    {
        //TODO Complete implementation
        /*
         * This method will draw the polygon object.  Look over the Graphics
         * class in the API for methods that will draw the polygon for you.
         * Make sure you handle whether the polygon is filled.
         */
    }

}
