
import javax.swing.JFrame;

/**
 * @author CS2334. Modified by: ?????
 * @version 21061018
 *         This class extends JFrame and contains the main method.
 */

public class DrawFrame extends JFrame
{
    private static final long serialVersionUID = 1L;
    private static DrawPanel drawPanel;

    /**
     * The DrawFrame constructor.
     * @param title The title of the frame.
     */
    public DrawFrame(String title)
    {
        super(title);

        // build the shapes
        //TODO Create the shapes that will represent Pikachu

        // create the panel and add the shapes to it
        //TODO Complete implementation

        
        // add panel to frame
        //TODO Complete implementation

        // finish setting up frame
        this.setSize(800, 600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

    }
    
    /**
     * The main method of this lab.
     * @param args Command line arguments.
     */
    public static void main(String[] args)
    {
        DrawFrame frame = new DrawFrame("Pikachu");
        // Force Web-Cat to not be unhappy with not using
        // the "frame" variable
        frame.getTitle();
    }

}
