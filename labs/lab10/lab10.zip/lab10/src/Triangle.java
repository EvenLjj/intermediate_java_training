import java.awt.Color;
import java.awt.Point;
import java.awt.Polygon;

/**
 * This class creates triangles.
 * 
 * @author Daniel
 * @version 20161018
 *
 */

public class Triangle extends Polygon
{

    /**
     * Triangle constructor.
     * 
     * @param pointB A point on the base of an isosceles triangle.
     * @param base The width of the base.
     * @param height The height at the apex of the triangle.
     * @param color Desired color of the triangle.
     * @param filled Whether or not the triangle should be filled.
     */
    public Triangle(Point pointB, int base, int height, Color color,
                    boolean filled)
    {
        //TODO Complete implementation
    }
}
