import java.awt.Color;
import java.awt.Point;

public class Diamond extends Polygon
{

    public Diamond(Point leftCorner, int edgeLength, Color color,
                    boolean filled)
    {
        //TODO Complete implementation
    }
}
