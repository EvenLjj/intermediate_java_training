import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 * @author CS2334. Modified by: ?????
 * @version 20161018
 *         This class is for an oval shape.
 */

public class Oval extends Shape
{
    private int diameter1;
    private int diameter2;

    /**
     * Constructor for Oval shapes
     * 
     * @param pointUL Upper left corner of the bounding box
     * @param diameter1 Diameter from left to right
     * @param diameter2 Diameter from top to bottom
     * @param color Desired color of the oval
     * @param filled Whether or not the oval should be filled
     */
    public Oval(Point pointUL, int diameter1, int diameter2, Color color,
                    boolean filled)
    {
      //TODO Complete implementation
    }

    //TODO Add other methods.

    /**
     * This method determines whether to draw a filled shape or an outline, and
     * then creates the shape accordingly.
     * 
     * @param g A Graphics object
     */
    @Override
    public void draw(Graphics g)
    {
        g.setColor(this.getColor());
        if (this.isFilled())
        {
            g.fillOval(location[0].x, location[0].y, diameter1, diameter2);
        } 
        else
        {
            g.drawOval(location[0].x, location[0].y, diameter1, diameter2);
        }
    }
}
