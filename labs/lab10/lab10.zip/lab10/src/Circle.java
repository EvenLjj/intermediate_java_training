import java.awt.Color;
import java.awt.Point;

/**
 * @author CS2334. Modified by: ?????
 * @version 20161018
 */

public class Circle extends Oval
{

    //TODO Complete implementation
}
