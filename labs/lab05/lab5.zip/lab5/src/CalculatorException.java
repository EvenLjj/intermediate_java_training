/**
 * 
 * @author CS2334.  Modified by ???
 * @version 2016-09-22
 * Lab 5
 * 
 * Exception class for representing exceptions that can
 * occur within a calculator.  
 * 
 * This class extends Exception, adding a boolean "quit" flag
 * that indicates that the user has typed "quit" (in any casing)
 *
 */
public class CalculatorException extends Exception {
    private boolean quit;
    
    // TODO: complete implementation
}
