import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;


/**
 * 
 * @author CS2334.  Modified by ????
 * @version 2016-11-01
 * 
 * The graphical user interface for interfacing with the weather database.
 * <P>
 * This frame includes inner classes for representing
 * <UL>
 * <LI> A menu bar
 * <LI> A selection panel
 * <LI> A data display panel
 * </UL>
 * 
 *
 */
public class WeatherFrame extends JFrame 
{

    /** Menu bar */
    private FileMenuBar fileMenuBar;
    /** Description of all stations */  
    private StationDefinitionList stationDefinitionList;
    /** Description of all statistics */
    private DataDefinitionList dataDefinitionList;
    /** Panel for selecting the station, statistic, and Year */
    private SelectionPanel selectionPanel;
    /** Panel for displaying statistic */
    private DataPanel dataPanel;

    /** Width of column 1 text fields in the data display */
    private final static int COLUMN_1_FIELD_WIDTH = 10;
    /** Width of column 2 text fields in the data display */
    private final static int COLUMN_2_FIELD_WIDTH = 20;


    ///////////////////////////////////////////////////////////////////
    /**
     * 
     * @author CS2334, modified by ???
     * @version 2016-11-01
     * 
     * Menu bar that provides file loading and program exit capabilities.
     *
     */
    public class FileMenuBar extends JMenuBar 
    {
        // Menu on the menu bar
        private JMenu menu;
        // Two options for the menu
        private JMenuItem menuExit;
        private JMenuItem menuOpen;
        // Reference to a file chooser pop-up
        private JFileChooser fileChooser;

        /**
         * Constructor: fully assemble the menu bar and attach the 
         * necessary action listeners.
         */
        public FileMenuBar() {
            // Create the menu and add it to the menu bar
            menu = new JMenu("File");
            add(menu);

            // TODO: complete the menu creation process
            

            // Action listener for exit
            menuExit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            });

            // Create the file chooser
            fileChooser = new JFileChooser(new File("./data"));

            // Action listener for file open
            menuOpen.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Ask for a file
                    // TODO: prompt the user for file
                    
                    int returnVal = ???
                            
                    // Did we get a file?
                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        // Yes
                        File file = fileChooser.getSelectedFile();
                        try {
                            // TODO: set the frame's cursor to be a "WAIT_CURSOR"
                            // TODO: load the specified file
                            // TODO: return the cursor to the default (null cursor)
                            
                            // Update the display
                            WeatherFrame.this.dataPanel.updateData();
                        }
                        catch (FileNotFoundException e2)
                        {
                            // File cannot be found
                            // TODO: pop-up window to ndicate that the file was not found
                            WeatherFrame.this.setCursor(null);
                        }
                        catch (IOException e2)
                        {
                            // Catch IO errors
                            // TODO: pop-up window to ndicate that there was an error
                            WeatherFrame.this.setCursor(null);
                        }
                        catch (Exception e2)
                        {
                            // Catch all other exceptions
                            // TODO: pop-up window to ndicate that there was an unspecified error
                            WeatherFrame.this.setCursor(null);
                        }

                    }
                }

            });

        }
    }
    
    /////////////////////////////////////////////////////////////////
    /**
     * 
     * @author CS 2334, Modified by ???
     * 
     * Panel that allows the user to select a station, variable 
     * and one or more years.
     *
     */
    public class SelectionPanel extends JPanel
    {

        /**
         * 
         */
        // The lists
        private JList<String> stationList;
        private JList<String> variableList;
        private JList<String> yearList;
        
        // List model for years
        private DefaultListModel<String> yearListModel;
        // Array list copy of the available yars
        private ArrayList<Integer> yearListValues;

        // Scrollers for the JLists
        private JScrollPane stationListScroller;
        private JScrollPane variableListScroller;
        private JScrollPane yearListScroller;

        // Lables 
        private JLabel stationLabel;
        private JLabel variableLabel;
        private JLabel yearListLabel;


        /**
         * Constructor: set up all of the component objects, 
         * initializing where
         * possible.  And - set up the layout
         * 
         * All listeners: call updateData()
         */
        public SelectionPanel()
        {
            this.setLayout(new GridBagLayout());
            
            // Create the station List 
            stationList = new JList<String>(
                    stationDefinitionList.getStationIds().toArray(new String[0]));
            stationListScroller = new JScrollPane(stationList);
            stationListScroller.setPreferredSize(new Dimension(300, 200));
            stationList.setVisibleRowCount(-1);
            stationList.setLayoutOrientation(JList.HORIZONTAL_WRAP);
            stationList.setSelectedIndex(0);
            stationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            stationList.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    WeatherFrame.this.dataPanel.updateData();
                }

            });
            // Force consistent spacing of each element in the station list
            stationList.setPrototypeCellValue("ACME--");

            // Create and configure the variable list
            // TODO: complete implementation
            

            // Create the list model for the year list
            yearListModel = new DefaultListModel<String>();
            // Default value
            yearListModel.add(0, "All");
            
            // TODO: complete the year selection implementation
            

            // Create the labels
            stationLabel = new JLabel("Select Station: ");
            variableLabel = new JLabel("Select Variable: ");
            yearListLabel = new JLabel("Select Year(s): ");
            
            // Lay out all of the objects in the panel
            GridBagConstraints layoutConst = new GridBagConstraints();

            // TODO: complete the layout
            
            
            ////////////////////////////////
            // Necessary for unit testing: DO NOT DELETE
            stationList.setName("Station List");
            variableList.setName("Variable List");
            yearList.setName("Year List");
            ////////////////////////////////
        }


    }
    /////////////////////////////////////////////////////////////////
    /**
     * 
     * @author CS 2334, modified by ???
     * 
     * Panel for displaying the data requested by the user.
     *
     */
    public class DataPanel extends JPanel
    {
        // Create the labels
        private JLabel stationLabel;
        private JLabel variableLabel;
        private JLabel minLabel;
        private JLabel maxLabel;
        private JLabel averageLabel;

        // Text fields for displaying data.  These will not
        // be editable
        private JTextField stationIdField;
        private JTextField variableIdField;
        private JTextField minVal;
        private JTextField maxVal;
        private JTextField averageVal;

        private JTextField variableUnitsField;
        private JTextField minDateField;
        private JTextField maxDateField;

        private JTextField stationNameField;
        private JTextField stationCityField;
        
        // Text area for the variable description to address 
        // the length of the string
        private JTextArea variableDescription;

        /**
         * Constructor.
         * 
         * Create all of the sub-components and lay them out
         */
        public DataPanel()
        {
            // Layout manager initialization
            this.setLayout(new GridBagLayout());

            // Create the labels
            stationLabel = new JLabel("Station:");
            variableLabel = new JLabel("Variable:");
            minLabel = new JLabel("Minimum:");
            maxLabel = new JLabel("Maximum:");
            averageLabel = new JLabel("Average");
            
            // Create the text fields.  The constructor takes
            // as input a width in the number of characters.
            // All of these fields are not editable
            stationIdField = new JTextField(COLUMN_1_FIELD_WIDTH);
            stationIdField.setEditable(false);
            // TODO: create the remaining sub-objects
            

            // Create the variable description text area.  We used 6 rows
            variableDescription = new JTextArea(6, COLUMN_2_FIELD_WIDTH);
            variableDescription.setWrapStyleWord(true);
            variableDescription.setLineWrap(true);

            // Lay out all of the pieces
            // TODO: complete layout
            
            
            ///////////////////////////////////////////////////
            // Necessary for unit testing: DO NOT EDIT
            stationIdField.setName("Station ID Field");
            variableIdField.setName("Variable ID Field");
            minVal.setName("Min Val");
            maxVal.setName("Max Val");
            averageVal.setName("Average Val");
            stationNameField.setName("Station Name Field");
            stationCityField.setName("Station City Field");
            variableUnitsField.setName("Variable Units Field");
            minDateField.setName("Min Date Field");
            maxDateField.setName("Max Date Field");
            variableDescription.setName("Variable Description");
            ///////////////////////////////////////////////////
            
            // Force the data panel to update
            updateData();
        }

        /**
         * This method is called any time the data panel needs to be updated 
         * with new information.
         * <P>
         * Notes:
         * <UL>
         * <LI> The <B>synchronized</B> keyword ensures that only one thread 
         * can be calling this method at any one time (the graphics system 
         * has many different execution threads in play at any one time).  
         * For now, consider this a bit of magic that you can just use.  
         * You will learn more in your operating systems class.
         * <LI> The approach for this method is to take information out of 
         * the selection
         * panel and figure out what to display in each of the Text Fields in 
         * the 
         * data panel
         * </UL>
         */
        public synchronized void updateData()
        {
            // Get a reference to the selection panel
            //SelectionPanel selectionPanel = WeatherFrame.this.selectionPanel;
            // Get the current station
            String stationId = selectionPanel.stationList.getSelectedValue();
            stationIdField.setText(stationId);

            // TODO: complete filling in the text fields and areas
            
            // Prepare to compute the statistics: do we have constraints?
            // Get the years
            int[] indices = 
                    selectionPanel.yearList.getSelectedIndices();

            // Translate indices into the appropriate KeyConstraints.  For this
            // project, we need no constraints (null) if we are taking all 
            // years,
            // otherwise we need one object that contains the list of years to
            // include
            // in the computation
            KeyConstraints constraints = null;

            // Parse the year selection.  In order for us to have anything 
            // but the
            // default, there must be more than zero selected items and 
            // the first one must not be "ALL"
            // TODO: complete the construction of the constraints

            // Query the statistics for the station
            // TODO: query the statistics

            // Report the results
            // TODO: report the statistics to the panel
            
            // Force the display to be updated
            WeatherFrame.this.repaint();
        }
    }

    /////////////////////////////////////////////////////////////////////////
    /**
     * WeatherFrame constructor
     * 
     * <UL>
     * <LI> Load the station and variable data
     * <LI> Create the menu bar
     * <LI> Create the selection and data panels
     * <LI> Lay the panels out
     * </UL>
     */
    public WeatherFrame() throws IOException
    {
        super("Mesonet Explorer");
        // Load the station and data info
        stationDefinitionList = 
                new StationDefinitionList("data/geoinfo.csv");
        dataDefinitionList = 
                new DataDefinitionList("data/DataTranslation.csv");
        
        // Hand the DailyData class the dataDefinitionList  
        DataDay.setDataDefinitionList(dataDefinitionList);

        // Configure the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Note: depending on your computer, you may want this to be larger
        setSize(1000, 600);

        // Menu bar
        fileMenuBar = new FileMenuBar();
        this.setJMenuBar(fileMenuBar);

        // GridBagLayout for the contents
        this.setLayout(new GridBagLayout());

        // TODO: create the selection and data panels, and add them to 
        //  this frame
        

        // Make the frame visible
        setVisible(true);
    }

    /**
     * Load a data set into the data structure and configure
     * the display
     * 
     * @param fileName Name of the file to load.
     * 
     * <P>
     * This method MUST:
     * <UL>
     * <LI> Load the specified data file (with help from stationDefinitionList)
     * <LI> Clear the contents of the yearListModel
     * <LI> Add "ALL" to the yearListModel
     * <LI> For every year reported by DataYear: add the year to both the 
     * yearListModel and the yearListValues array.  Note that both lists need
     * to be in year order (i.e., 2000 comes before 2001)
     * <LI> Reset the yearList selected index to zero
     * </UL>
     */
    public void loadData(String fileName) throws IOException
    {
        stationDefinitionList.loadData(fileName);

        // Update the displayed set of available years
        
        // Clear out our lists
        WeatherFrame.this.selectionPanel.yearListModel.removeAllElements();
        WeatherFrame.this.selectionPanel.yearListValues.clear();
        
        // Add All to the front of the year list model
        WeatherFrame.this.selectionPanel.yearListModel.addElement("All");
        
        // Loop over loaded years add to both the model and the values
        // TODO: complete implementation

        
        // Reset the selected item to be ALL
        WeatherFrame.this.selectionPanel.yearList.setSelectedIndex(0);
    }
    
    /**
     * This method exists only to trick Web-Cat into not taking
     * certain style points off...
     */
    public void makeWebCatHappy()
    {
        fileMenuBar.toString();
        
    }


}
