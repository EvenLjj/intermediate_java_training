/**
 * 
 * @author CS2334.  Modified by: ?????
 * <P>
 * Date: 2016-09-10 <BR>
 * Project 1
 * <P>
 * This class represents individual, real-valued samples.  This class
 * explicitly addresses the fact that some samples are invalid.
 *
 */

public class Sample {
	/** The observed value.  */
	private double value;
	
	/** Indicates whether the observation is a valid one */
	private boolean valid;
	
	// TODO: complete the implementation
	
}
